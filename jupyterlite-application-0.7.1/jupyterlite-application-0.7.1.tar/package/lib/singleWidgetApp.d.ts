import type { JupyterFrontEndPlugin } from '@jupyterlab/application';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { LabStatus } from '@jupyterlab/application/lib/status';
import type { IRenderMime } from '@jupyterlab/rendermime-interfaces';
import type { ISingleWidgetShell } from './singleWidgetShell';
/**
 * App is the main application class. It is instantiated once and shared.
 */
export declare class SingleWidgetApp extends JupyterFrontEnd<ISingleWidgetShell> {
    /**
     * Construct a new SingleWidgetApp object.
     *
     * @param options The instantiation options for an application.
     */
    constructor(options?: SingleWidgetApp.IOptions);
    /**
     * The name of the application.
     */
    readonly name = "Single Widget Application";
    /**
     * A namespace/prefix plugins may use to denote their provenance.
     */
    readonly namespace = "Single Widget Application";
    /**
     * The application busy and dirty status signals and flags.
     */
    readonly status: LabStatus;
    /**
     * The version of the application.
     */
    readonly version: string;
    /**
     * The JupyterLab application paths dictionary.
     */
    get paths(): JupyterFrontEnd.IPaths;
}
/**
 * A namespace for App statics.
 */
export declare namespace SingleWidgetApp {
    /**
     * The instantiation options for an App application.
     */
    interface IOptions extends JupyterFrontEnd.IOptions<ISingleWidgetShell>, Partial<IInfo> {
    }
    /**
     * The information about a Jupyter Notebook application.
     */
    interface IInfo {
        /**
         * The mime renderer extensions.
         */
        readonly mimeExtensions: IRenderMime.IExtensionModule[];
    }
    /**
     * The interface for a module that exports a plugin or plugins as
     * the default value.
     */
    interface IPluginModule {
        /**
         * The default export.
         */
        default: JupyterFrontEndPlugin<any> | JupyterFrontEndPlugin<any>[];
    }
}
