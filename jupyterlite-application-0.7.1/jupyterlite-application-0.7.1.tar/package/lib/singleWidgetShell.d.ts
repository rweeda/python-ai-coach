import type { JupyterFrontEnd } from '@jupyterlab/application';
import type { DocumentRegistry } from '@jupyterlab/docregistry';
import { Token } from '@lumino/coreutils';
import type { ISignal } from '@lumino/signaling';
import type { FocusTracker } from '@lumino/widgets';
import { Widget } from '@lumino/widgets';
/**
 * The single widget application shell token.
 */
export declare const ISingleWidgetShell: Token<ISingleWidgetShell>;
/**
 * The single widget application shell interface.
 */
export interface ISingleWidgetShell extends SingleWidgetShell {
}
/**
 * The application shell.
 */
export declare class SingleWidgetShell extends Widget implements JupyterFrontEnd.IShell {
    constructor();
    /**
     * A signal emitted when the current widget changes.
     */
    get currentChanged(): ISignal<ISingleWidgetShell, FocusTracker.IChangedArgs<Widget>>;
    /**
     * The current widget in the shell's main area.
     */
    get currentWidget(): Widget | null;
    /**
     * Activate a widget in its area.
     */
    activateById(id: string): void;
    /**
     * Add a widget to the application shell.
     *
     * @param widget - The widget being added.
     *
     * @param area - Optional region in the shell into which the widget should
     * be added.
     *
     * @param options - Optional open options.
     *
     */
    add(widget: Widget, area?: Shell.Area, options?: DocumentRegistry.IOpenOptions): void;
    /**
     * Return the list of widgets for the given area.
     *
     * @param area The area
     */
    widgets(area: Shell.Area): IterableIterator<Widget>;
    private _main;
    private _currentChanged;
}
/**
 * A namespace for Shell statics
 */
export declare namespace Shell {
    /**
     * The areas of the application shell where widgets can reside.
     */
    type Area = 'main';
}
